﻿using Abp.AutoMapper;
using Sideas.ABP.Authentication.External;

namespace Sideas.ABP.Models.TokenAuth
{
    [AutoMapFrom(typeof(ExternalLoginProviderInfo))]
    public class ExternalLoginProviderInfoModel
    {
        public string Name { get; set; }

        public string ClientId { get; set; }
    }
}
