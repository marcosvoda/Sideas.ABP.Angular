﻿namespace Sideas.ABP
{
    public class ABPConsts
    {
        public const string LocalizationSourceName = "ABP";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
